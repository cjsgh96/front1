package 프로젝트2차ver2;

public class 우리도서관 {
// 이름, 주소, 운영시간, 휴관일, 대여권수, 대여일수, 전화번호
	public void 이름() {
		System.out.println(" 이     름 : 여의샛강도서관");
	}
	public void 주소(){
		System.out.println(" 주     소 : 영등포구 여의대로 24");
	}
	public void 운영시간() {
		System.out.println(" 운 영 시 간 : 평일 09:00~20:00\n\t    주말 09:00~17:00");
	}
	public void 휴관일() {
		System.out.println(" 휴  관  일 : 매주 월요일, 법정공휴일");
	}
	public void 대여권수() {
		System.out.println(" 대 여 권 수 : 개인당 최대 10권");
	}
	public void 대여일수() {
		System.out.println(" 대 여 일 수 : 최대 21일, 연장불가");
	}
	public void 전화번호() {
		System.out.println(" 전 화 번 호 : 02-2629-2222");
	}
	public void now도서관() {
				
	}
}
